Compile:  gcc --std=gnu99 -o smallsh main.c
Run:      ./smallsh
